//
//  model.swift
//  lab09ne
//
//  Created by Luke Kuhara on 2021/5/26.
//

import Foundation
struct game {
    var player : Int
    var com: Int
    var winner: String = ""
}
