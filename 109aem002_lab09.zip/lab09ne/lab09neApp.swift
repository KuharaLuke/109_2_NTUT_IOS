//
//  lab09neApp.swift
//  lab09ne
//
//  Created by Luke Kuhara on 2021/5/26.
//

import SwiftUI

@main
struct lab09neApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(VM:viewmodel())
        }
    }
}
