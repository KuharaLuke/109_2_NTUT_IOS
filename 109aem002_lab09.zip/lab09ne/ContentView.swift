//
//  ContentView.swift
//  lab09ne
//
//  Created by Luke Kuhara on 2021/5/26.
//


import SwiftUI



struct ContentView: View {
    @ObservedObject var VM: viewmodel
    
    var body: some View {
        
        VStack(spacing:50){
            
                Text("猜拳遊戲")
                    .font(.system(size: 24))
                    .bold()
              
            
            .padding([.top],30)
            
                HStack{
                    Image("Korosan")
                        .resizable()
                    chooseicon(input: VM.comint)
                    
                    
                    
                }
                .padding([.top],20)
                .frame(width: 300, height: 150, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                
            
        ZStack{
                Image("line")
            
            getimage(winner: VM.winner)
                    .resizable()
                    .frame(width: 200, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            
            
        }
        
                
          
                HStack{
                    Image("Listener")
                        .resizable()
                    chooseicon(input: VM.playerint)
                    
                    
                    
                }
                .frame(width: 300, height: 150, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Button(action: {
                    VM.startgame()
                }, label: {
                    Text("出拳") .font(.title)
                    Image("pss")
                        .resizable()
                })
                .frame(width: 200, height: 125, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                
            HStack{
                Text("勝者:") .font(.title)
                if VM.winner == ""{
                    Text("請猜拳！")
                }else if VM.winner == "player"{
                    Image("Listener")
                        .resizable()
                        .frame(width:100,height:100)
                }else if VM.winner=="com"{
                    Image("Korosan")
                        .resizable()
                        .frame(width:100,height:100)
                }else{
                    Image("flathand")
                        .resizable()
                        .frame(width:100,height:100)
                }
            }
            
                Spacer()
            
           
            }
        
       
     
        
            
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(VM: viewmodel())
    }
}


func chooseicon(input: Int) -> Image{
    switch input {
    case 0:
        return Image("rock")
            .resizable()
    case 1:
        return Image("scissor")
            .resizable()
    case 2:
        return Image("paper")
            .resizable()
    default:
        return Image("rock")
            .resizable()
    }
}


func getimage(winner: String) -> Image{
    switch winner {
    case "nobody":
        return Image("flathand")
    case "player":
        return Image("win")
    case "com":
        return Image("lose")
    default:
        return Image("duel")
    }
}
